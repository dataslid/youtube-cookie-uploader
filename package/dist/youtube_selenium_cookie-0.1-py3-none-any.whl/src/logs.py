import logging

def setup():
    # Configure the logging settings
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
