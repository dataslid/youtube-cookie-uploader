class CookieTimeOutError(Exception):
    pass